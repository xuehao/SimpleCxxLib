// It's possible to create and edit header files

#include <iostream>
