You can open this project with Qt Creator.
(see https://web.stanford.edu/dept/cs_edu/resources/qt/)

Also Java 8 is needed for running programs properly.
(see https://adoptium.net/temurin/releases/?version=8)